/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mcq_app;

/**
 *
 * @author kanha
 */
public class CountManager {
    private static int count = 0;

    public static int getCount() {
        return count;
    }

    public static void setCount(int newCount) {
        count = newCount;
    }
}

